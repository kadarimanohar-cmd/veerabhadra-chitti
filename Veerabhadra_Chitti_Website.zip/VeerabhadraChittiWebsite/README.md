# Veerabhadra Chitti Website (PWA-ready prototype)

## Quick preview
Open `index.html` in a browser. For install/offline PWA behavior, host it over HTTPS (GitHub Pages, Netlify, or similar).

## Demo login
Any 10-digit mobile number + OTP `123456`.

## Features
- Multiple chitti schemes
- Members per chitti
- Monthly paid/pending tracking
- Payment history
- CSV reports
- Telugu/English toggle
- WhatsApp/SMS reminder handoff (opens apps; user sends manually)
- Browser localStorage persistence
- PWA manifest and service worker

## Important limitations
This is a functional browser prototype, not a production financial system:
- Demo OTP is not real authentication.
- Data stays in one browser/device; there is no shared cloud database or admin/member role security.
- Reminders are not automatic or scheduled.
- No real payment gateway, auction payout processing, or verified receipts.
Before real-world use, add a secure backend/database, OTP provider, authorization rules, backups, audit trail, and approved messaging integrations.
